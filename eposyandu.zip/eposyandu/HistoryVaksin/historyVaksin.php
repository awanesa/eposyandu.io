<?php
session_start();
if (!isset($_SESSION['username_admin'])) {
    header("location: ../index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../img/icon/logoremove.png" type="image/x-icon">
    <title>Riwayat Vaksin Anak</title>
    <style type="text/css">
        body {
            font-family: "Futura Md BT";
            background-color: aquamarine !important;
            background-size: cover;
            background-repeat: repeat-y;
        }

        .form-group {
            margin-left: -15px;
        }
    </style>
</head>

<body>
    <?php
    include "../sidebar.html";
    ?>

    <div class="container" style="margin-top: 130px; margin-left: 230px;">
        <h1>Riwayat Vaksin Anak</h1><br>
        <div class="container row mt-4">
            <div class="col">
                <div class="form-group">
                    <div class="row">
                        <div class="col-7">
                            <select class="selectpicker form-control" data-live-search="true" id="id_anak"></select>
                        </div>
                        <div class="col">
                            <span id="statusPilihAnak"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <form id="searchForm" class="form-inline m-0" method="get" action="">
                    <div class="form-group me-3 m-0">
                        <input type="hidden" id="selectedAnak" name="selectedAnak" value="<?php echo isset($_GET['selectedAnak']) ? $_GET['selectedAnak'] : '' ?>">
                        <input type="text" class="form-control" id="searchInput" name="key" placeholder="Search..." value="<?php echo isset($_GET['key']) ? $_GET['key'] : '' ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Search</button>
                </form>
            </div>
        </div>
        <table id="ttable" border="0" class="table table-hover table-light table-striped">
            <thead class="bg-dark">
                <tr class="text-white">
                    <th>Tanggal Imunisasi</th>
                    <th class="align-middle" width="60%">Nama Vaksin</th>
                </tr>
            </thead>
            <tbody id="content"></tbody>
        </table>
    </div>
    <button type="button" onclick="window.location.href='../home3.php'" class="btn shadow-sm p-2 bg-success rounded" id="button">Kembali</button>

    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    <script type=text/javascript>
        var id_anak;
        var key;
        $(document).ready(function() {
            $("#statusPilihAnak").html("loading...");
            $("#id_anak").load("../api/HistoryVaksin/optionAnak.php", "func_history=ambil_option_anak", function() {
                $("#statusPilihAnak").html("");
                var currentUrl = new URL(window.location.href);
                var searchParams = currentUrl.searchParams;
                var search_key = "";
                var selected_anak = "";
                if (searchParams.has('key') && searchParams.has('selectedAnak')) {
                    search_key = searchParams.get('key');
                    selected_anak = searchParams.get('selectedAnak');
                    $("#id_anak").val(selected_anak);
                    getAllData(selected_anak, search_key);
                }
            });

            $("#id_anak").change(function() {
                id_anak = $(this).children("option:selected").val();
                key = $("#searchInput").val();
                $("#selectedAnak").val(id_anak);
                getAllData(id_anak, key);
            });

            $('#searchForm').on('submit', function(event) {
                event.preventDefault(); // Prevent the default form submission
                var searchKey = $('#searchInput').val();
                var selected_anak = $('#selectedAnak').val();
                var currentUrl = new URL(window.location.href);
                var searchParams = currentUrl.searchParams;

                // Set the key parameter
                searchParams.set('key', searchKey);
                searchParams.set('selectedAnak', selected_anak);

                // Redirect to the updated URL
                window.location.href = currentUrl.origin + currentUrl.pathname + '?' + searchParams.toString();
            });
        });


        function getAllData(id_anak, key_search) {
            $.ajax({
                type: "GET",
                url: "../api/HistoryVaksin/readHistoryVaksin.php",
                data: {
                    id_anak: id_anak,
                    key: key_search
                },
                cache: false,
                success: function(msg) {
                    data = msg.records;
                    var content = "";
                    if (msg.message == "500 ERROR") {
                        content += "<tr>";
                        content += "<td colspan='2'>Tidak Ada Riwayat Vaksin</td>";
                        content += "</tr>";
                        $("#content").html(content);
                    } else {
                        for (let index = 0; index < data.length; index++) {
                            const element = data[index];
                            content += "<tr>";
                            content += "<td>" + element.tgl_imunisasi + "</td>";
                            content += "<td>" + element.id_vaksin + "</td>";
                            content += "</tr>";
                        }
                        $("#content").html(content);
                    }
                }
            });
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>
</body>

</html>
<?php

class Timbangan
{
	private $conn;
	private $table_nama = "ref_timbangan";

	public $id_penimbangan;
	public $id_anak;
	public $nama_anak;
	public $berat_badan;
	public $tinggi_badan;
	public $tanggal_penimbangan;
	public $fromDate;
	public $toDate;
	public $startPage;
	public $dataPerPage;

	public function __construct($db)
	{
		$this->conn = $db;
		$this->id_penimbangan = uniqid("tim");
	}
	public function read()
	{
		$query = "SELECT ref_timbangan.id_timbangan, ref_timbangan.id_anak, ref_timbangan.tanggal_penimbangan, ref_anak.nama_anak, 
			ref_anak.id_ibu, ref_ibu.nama_ibu, ref_ibu.alamat_ibu,
			ref_anak.jk_anak, ref_anak.tgl_lahir_anak, ref_timbangan.berat_badan, ref_timbangan.tinggi_badan FROM " . $this->table_nama .
			" LEFT JOIN ref_anak ON ref_timbangan.id_anak = ref_anak.id_anak" .
			" LEFT JOIN ref_ibu ON ref_anak.id_ibu = ref_ibu.id_ibu";


		$stmt = $this->conn->prepare($query);
		$stmt->execute();

		return $stmt;
	}

	public function readPagination()
	{
		$query = "SELECT ref_timbangan.id_timbangan, ref_timbangan.id_anak, ref_timbangan.tanggal_penimbangan, ref_anak.nama_anak, 
			ref_anak.id_ibu, ref_ibu.nama_ibu, ref_ibu.alamat_ibu,
			ref_anak.jk_anak, ref_anak.tgl_lahir_anak, ref_timbangan.berat_badan, ref_timbangan.tinggi_badan, ref_anak.usia_anak FROM " . $this->table_nama .
			" LEFT JOIN ref_anak ON ref_timbangan.id_anak = ref_anak.id_anak" .
			" LEFT JOIN ref_ibu ON ref_anak.id_ibu = ref_ibu.id_ibu LIMIT $this->startPage, $this->dataPerPage";

		$stmt = $this->conn->prepare($query);
		$stmt->execute();

		return $stmt;
	}

	public function create()
	{

		// query to insert record
		$query = "INSERT INTO
						" . $this->table_nama . " VALUES ('$this->id_penimbangan','$this->id_anak', '$this->berat_badan', '$this->tinggi_badan', '" . $this->tanggal_penimbangan . "')";
		$stmt = $this->conn->prepare($query);
		if ($stmt->execute()) {
			return true;
		}
		return false;
	}

	function read_one()
	{

		// query to read single record
		$query = "SELECT ref_timbangan.id_timbangan, ref_timbangan.id_anak, ref_timbangan.tanggal_penimbangan, ref_anak.nama_anak as Anak, 
			ref_anak.id_ibu, ref_ibu.nama_ibu, ref_ibu.alamat_ibu,
			ref_anak.jk_anak, ref_anak.tgl_lahir_anak, ref_timbangan.berat_badan, ref_timbangan.tinggi_badan FROM " . $this->table_nama .
			" LEFT JOIN ref_anak ON ref_timbangan.id_anak = ref_anak.id_anak" .
			" LEFT JOIN ref_ibu ON ref_anak.id_ibu = ref_ibu.id_ibu WHERE id_timbangan='$this->id_penimbangan'";

		// prepare query statement
		$stmt = $this->conn->prepare($query);

		// bind id of product to be updated

		// execute query
		$stmt->execute();

		// get retrieved row
		$row = $stmt->fetch(PDO::FETCH_ASSOC);

		// set values to object properties
		$this->tinggi_badan = $row['tinggi_badan'];
		$this->berat_badan = $row['berat_badan'];
		$this->nama_anak = $row['Anak'];
	}

	public function update()
	{

		// update query
		$query = "UPDATE $this->table_nama 
					SET id_anak = '$this->id_anak', 
						berat_badan = '$this->berat_badan', 
						tinggi_badan = '$this->tinggi_badan ', 
						berat_badan = '$this->berat_badan',
            tanggal_penimbangan = '$this->tanggal_penimbangan'
					WHERE id_timbangan = '$this->id_penimbangan'";

		// prepare query statement
		$stmt = $this->conn->prepare($query);

		// execute the query
		if ($stmt->execute()) {
			return true;
		}

		return false;
	}

	function delete()
	{

		// delete query
		$query = "DELETE FROM " . $this->table_nama . " WHERE id_timbangan = '$this->id_penimbangan'";

		// prepare query
		$stmt = $this->conn->prepare($query);

		// execute query
		if ($stmt->execute()) {
			return true;
		}
		return false;
	}

	public function dataRekap()
	{
		$query = "SELECT ref_timbangan.id_timbangan, ref_timbangan.id_anak, ref_anak.nama_anak, 
			ref_anak.id_ibu, ref_ibu.nama_ibu, ref_ibu.alamat_ibu, ref_timbangan.tanggal_penimbangan,
			ref_anak.jk_anak, ref_anak.usia_anak, ref_anak.tgl_lahir_anak, ref_timbangan.berat_badan, ref_timbangan.tinggi_badan FROM " . $this->table_nama .
			" LEFT JOIN ref_anak ON ref_timbangan.id_anak = ref_anak.id_anak" .
			" LEFT JOIN ref_ibu ON ref_anak.id_ibu = ref_ibu.id_ibu WHERE tanggal_penimbangan BETWEEN '$this->fromDate' AND '$this->toDate'";

		$stmt = $this->conn->prepare($query);
		$stmt->execute();

		return $stmt;
	}
}
